import logging
from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from PyPDF2 import PdfMerger
import os
from PIL import Image
import pytesseract

TOKEN = os.getenv("BOT_TOKEN")
logging.basicConfig(level=logging.INFO)
pdfs = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Send me PDF files or images. Use /merge to combine PDFs.")

async def handle_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    file = await update.message.document.get_file()
    file_path = f"{user_id}_{update.message.document.file_name}"
    await file.download_to_drive(file_path)

    if file_path.endswith(".pdf"):
        pdfs.setdefault(user_id, []).append(file_path)
        await update.message.reply_text(f"PDF saved: {file_path}")
    elif file_path.lower().endswith((".jpg", ".jpeg", ".png")):
        text = pytesseract.image_to_string(Image.open(file_path))
        await update.message.reply_text(f"Extracted text:
{text[:4000]}")
        os.remove(file_path)
    else:
        await update.message.reply_text("Unsupported file. Only PDFs and images are allowed.")

async def merge_pdfs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    user_pdfs = pdfs.get(user_id, [])
    if not user_pdfs:
        await update.message.reply_text("No PDFs to merge.")
        return

    merger = PdfMerger()
    for pdf in user_pdfs:
        merger.append(pdf)
    output_path = f"{user_id}_merged.pdf"
    merger.write(output_path)
    merger.close()

    with open(output_path, "rb") as f:
        await update.message.reply_document(document=InputFile(f, filename="merged.pdf"))
    os.remove(output_path)
    for f in user_pdfs:
        os.remove(f)
    pdfs[user_id] = []

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("merge", merge_pdfs))
app.add_handler(MessageHandler(filters.Document.ALL, handle_file))

app.run_polling()